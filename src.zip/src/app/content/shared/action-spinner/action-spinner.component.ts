import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-action-spinner',
  templateUrl: './action-spinner.component.html',
  styleUrls: ['./action-spinner.component.scss']
})
export class ActionSpinnerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
