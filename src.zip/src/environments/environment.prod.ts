export const environment = {
  production: true,
  apiUrl: 'https://digitalbondmena.com/digitalBondMobileApp/api/'
};
